MinGW 3.4.2 + WinBGIm 6.0 (2004)
ACC 30.04.2020
================================


1. About
--------
This package contains the needed files for compiling in Windows C++ programs that use the graphics.h library (still taught in some Computer Science classes). Modern IDEs do not typically compile code which includes graphics.h. For Visual Studio users there is a bloated package which is able to compile WinBGIm code: https://www.cs.colorado.edu/~main/bgi/visual/
Code::Blocks 17.12 or 20.03 have newer versions of MinGW, which do not compile the obsolete C++ code in which WinBGIm was written.
Also, Visual Studio Code 1.44+ has the same problems, when used with the current version of MinGW. 

All the contents are extracted from an old portable DevC++ 4.9.9.2 archive. I guess you can extract the same folders from a local installation of it: https://www.cs.colorado.edu/~main/bgi/dev-c++/devcpp-4.9.9.2_setup.exe Then you could add the WinBGIm library files (graphics.h and libbgi.a), see https://www.cs.colorado.edu/~main/bgi/dev-c++/ (I tried and it didn't work.)

The only modifications were made to fix a well-known bug in the original graphics.h, line 302:
- from: int left=0, int right=0, int right=INT_MAX, int bottom=INT_MAX,
- to:   int left=0, int top=0, int right=INT_MAX, int bottom=INT_MAX,

Of course, copyright belongs to the original authors. My only contribution is fixing the above bug and writing this file.


2. Usage instructions
---------------------
Extract the mingw3.4.2.zip archive to a desired location. This path will be referred to when configuring compiler options.


2.1 Code::Blocks 20.03 http://codeblocks.org/

* Go to the menu: Settings > Compiler.

* Select "GNU GCC Compiler" (if it isn't already selected), click Copy, set whatever compiler name you want (hint: GCC + BGI).

* Go to the "Linker settings" tab and in "Other linker options" paste these lines:
-lbgi
-lgdi32
-lcomdlg32
-luuid
-loleaut32
-lole32

* Go to the "Toolchain executables" tab and add the path where you extracted this package to "Compiler's installation directory".

* Now click OK and test your setup with a .cpp file that includes graphics.h. To do that, create a new empty project, set its compiler to the one you added (e.g. GCC + BGI), add a test.cpp file with the following content:

#include <graphics.h>

int main( ) {
    initwindow(400, 300, "First Sample");
    circle(100, 50, 40);
    while (!kbhit( )) {
        delay(200);
    }
    return 0;
}

* Build and run.


2.2 Visual Studio Code 1.44.2 https://code.visualstudio.com/

* Follow the instructions for building C++ with MinGW: https://code.visualstudio.com/docs/cpp/config-mingw

* Now you need to setup a project default build task, as follows.

* First create a new folder in a location of your choice.

* Open Visual Studio Code; in the menu click File > Open folder... and select the folder you created at the previous step.

* In the menu click Terminal > Config Default Build Task... then click "Create tasks.json file from template", select whatever option you want (the contents will be replaced with proper settings).

* In the opened tasks.json file replace all the contents with the following and then save and close it:
{
	"version": "2.0.0",
	"tasks": [{
		"type": "shell",
		"label": "Build with Mingw 3.4.2 (winbgi)",
		// FIXME: change this line to your local path (see above, the first line from "Usage instructions")
		// be careful to escape the backslashes
		"command": "D:\\Projects\\mingw3.4.2\\bin\\g++.exe", 
		"args": [
			"-g",
			"${file}",
			"-lbgi",
			"-lgdi32",
			"-lcomdlg32",
			"-luuid",
			"-loleaut32",
			"-lole32",
			"-o",
			"${fileDirname}\\${fileBasenameNoExtension}.exe"
		],
		"options": {
			// FIXME: same as above
			"cwd": "D:\\Projects\\mingw3.4.2\\bin\\"
		},
		"problemMatcher": [
			"$gcc"
		],
		"group": {
			"kind": "build",
			"isDefault": true
		}
	}]
}

* Use the sidebar to create a new test.cpp file in the opened folder. Paste this code to test the setup:

#include <graphics.h>

int main( ) {
    initwindow(400, 300, "First Sample");
    circle(100, 50, 40);
    while (!kbhit( )) {
        delay(200);
    }
    return 0;
}

* Go to the menu, click Terminal > Run Build Task...

* If all went OK you can run the generated executable directly or from Visual Studio Code's terminal (click the + sign to the right of the dropdown "1: Task - Build with Mingw 3.4.2 (winbgi)" and, at the prompt, run your program; if you start in PowerShell, prefix the program name with .\).

* If you enjoy Visual Studio Code like I do, you can customize it with lots of extensions, formatters, keyboard shortcuts, themes...

HTH